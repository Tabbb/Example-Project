﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AllCoursesReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.Project2DataSet = New ITE_370_Programming_Assignment_2.Project2DataSet()
        Me.tblCourseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.tblCourseTableAdapter = New ITE_370_Programming_Assignment_2.Project2DataSetTableAdapters.tblCourseTableAdapter()
        CType(Me.Project2DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tblCourseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ReportViewer1
        '
        Me.ReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource1.Name = "DataSet1"
        ReportDataSource1.Value = Me.tblCourseBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource1)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "ITE_370_Programming_Assignment_2.DisplayCourses.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(639, 377)
        Me.ReportViewer1.TabIndex = 0
        '
        'Project2DataSet
        '
        Me.Project2DataSet.DataSetName = "Project2DataSet"
        Me.Project2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'tblCourseBindingSource
        '
        Me.tblCourseBindingSource.DataMember = "tblCourse"
        Me.tblCourseBindingSource.DataSource = Me.Project2DataSet
        '
        'tblCourseTableAdapter
        '
        Me.tblCourseTableAdapter.ClearBeforeFill = True
        '
        'AllCoursesReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(639, 377)
        Me.Controls.Add(Me.ReportViewer1)
        Me.Name = "AllCoursesReport"
        Me.Text = "AllCoursesReport"
        CType(Me.Project2DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tblCourseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents tblCourseBindingSource As BindingSource
    Friend WithEvents Project2DataSet As Project2DataSet
    Friend WithEvents tblCourseTableAdapter As Project2DataSetTableAdapters.tblCourseTableAdapter
End Class
