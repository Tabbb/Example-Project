﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEditTextbook
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtTextbookID = New System.Windows.Forms.TextBox()
        Me.txtAuthor = New System.Windows.Forms.TextBox()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.txtPublisher = New System.Windows.Forms.TextBox()
        Me.txtCost = New System.Windows.Forms.TextBox()
        Me.btnEditTextbook = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblTextbookID = New System.Windows.Forms.Label()
        Me.lblAuthor = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblPublisher = New System.Windows.Forms.Label()
        Me.lblCost = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtTextbookID
        '
        Me.txtTextbookID.Location = New System.Drawing.Point(227, 25)
        Me.txtTextbookID.Name = "txtTextbookID"
        Me.txtTextbookID.ReadOnly = True
        Me.txtTextbookID.Size = New System.Drawing.Size(190, 22)
        Me.txtTextbookID.TabIndex = 0
        '
        'txtAuthor
        '
        Me.txtAuthor.Location = New System.Drawing.Point(227, 53)
        Me.txtAuthor.Name = "txtAuthor"
        Me.txtAuthor.Size = New System.Drawing.Size(190, 22)
        Me.txtAuthor.TabIndex = 1
        '
        'txtTitle
        '
        Me.txtTitle.Location = New System.Drawing.Point(227, 81)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(263, 22)
        Me.txtTitle.TabIndex = 2
        '
        'txtPublisher
        '
        Me.txtPublisher.Location = New System.Drawing.Point(227, 109)
        Me.txtPublisher.Name = "txtPublisher"
        Me.txtPublisher.Size = New System.Drawing.Size(145, 22)
        Me.txtPublisher.TabIndex = 3
        '
        'txtCost
        '
        Me.txtCost.Location = New System.Drawing.Point(227, 137)
        Me.txtCost.Name = "txtCost"
        Me.txtCost.Size = New System.Drawing.Size(100, 22)
        Me.txtCost.TabIndex = 4
        '
        'btnEditTextbook
        '
        Me.btnEditTextbook.Location = New System.Drawing.Point(43, 177)
        Me.btnEditTextbook.Name = "btnEditTextbook"
        Me.btnEditTextbook.Size = New System.Drawing.Size(178, 52)
        Me.btnEditTextbook.TabIndex = 5
        Me.btnEditTextbook.Text = "Update Textbook"
        Me.btnEditTextbook.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(281, 178)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(171, 51)
        Me.btnClose.TabIndex = 6
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lblTextbookID
        '
        Me.lblTextbookID.AutoSize = True
        Me.lblTextbookID.Location = New System.Drawing.Point(11, 28)
        Me.lblTextbookID.Name = "lblTextbookID"
        Me.lblTextbookID.Size = New System.Drawing.Size(210, 17)
        Me.lblTextbookID.TabIndex = 7
        Me.lblTextbookID.Text = "Textbook 13-digit ISBN Number:"
        '
        'lblAuthor
        '
        Me.lblAuthor.AutoSize = True
        Me.lblAuthor.Location = New System.Drawing.Point(85, 56)
        Me.lblAuthor.Name = "lblAuthor"
        Me.lblAuthor.Size = New System.Drawing.Size(136, 17)
        Me.lblAuthor.TabIndex = 8
        Me.lblAuthor.Text = "Author's Last Name:"
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Location = New System.Drawing.Point(182, 84)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(39, 17)
        Me.lblTitle.TabIndex = 9
        Me.lblTitle.Text = "Title:"
        '
        'lblPublisher
        '
        Me.lblPublisher.AutoSize = True
        Me.lblPublisher.Location = New System.Drawing.Point(150, 112)
        Me.lblPublisher.Name = "lblPublisher"
        Me.lblPublisher.Size = New System.Drawing.Size(71, 17)
        Me.lblPublisher.TabIndex = 10
        Me.lblPublisher.Text = "Publisher:"
        '
        'lblCost
        '
        Me.lblCost.AutoSize = True
        Me.lblCost.Location = New System.Drawing.Point(181, 140)
        Me.lblCost.Name = "lblCost"
        Me.lblCost.Size = New System.Drawing.Size(40, 17)
        Me.lblCost.TabIndex = 11
        Me.lblCost.Text = "Cost:"
        '
        'frmEditTextbook
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(502, 259)
        Me.Controls.Add(Me.lblCost)
        Me.Controls.Add(Me.lblPublisher)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.lblAuthor)
        Me.Controls.Add(Me.lblTextbookID)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnEditTextbook)
        Me.Controls.Add(Me.txtCost)
        Me.Controls.Add(Me.txtPublisher)
        Me.Controls.Add(Me.txtTitle)
        Me.Controls.Add(Me.txtAuthor)
        Me.Controls.Add(Me.txtTextbookID)
        Me.Name = "frmEditTextbook"
        Me.Text = "Edit Textbook"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtTextbookID As TextBox
    Friend WithEvents txtAuthor As TextBox
    Friend WithEvents txtTitle As TextBox
    Friend WithEvents txtPublisher As TextBox
    Friend WithEvents txtCost As TextBox
    Friend WithEvents btnEditTextbook As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents lblTextbookID As Label
    Friend WithEvents lblAuthor As Label
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblPublisher As Label
    Friend WithEvents lblCost As Label
End Class
