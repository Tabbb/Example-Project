﻿Public Class frmEditTextbook
    'Programmed by Brittany Eccles
    Private Sub frmEditTextbook_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dgvIndex As Integer
        dgvIndex = frmTextbook.dgvTextbooks.CurrentRow.Index
        txtTextbookID.Text = frmTextbook.dgvTextbooks.Rows(dgvIndex).Cells(0).Value
        txtAuthor.Text = frmTextbook.dgvTextbooks.Rows(dgvIndex).Cells(1).Value
        txtTitle.Text = frmTextbook.dgvTextbooks.Rows(dgvIndex).Cells(2).Value
        txtPublisher.Text = frmTextbook.dgvTextbooks.Rows(dgvIndex).Cells(3).Value
        txtCost.Text = frmTextbook.dgvTextbooks.Rows(dgvIndex).Cells(4).Value
        txtAuthor.Focus()
    End Sub
    Function dataok() As Boolean
        If txtTextbookID.Text = "" Or Len(txtTextbookID.Text) <> 13 Then
            MessageBox.Show("Please enter the 13 digit ISBN number")
            txtTextbookID.Focus()
            Return False
        ElseIf txtTextbookID.Text.Substring(0, 3) <> "978" Then
            MessageBox.Show("Please enter the number 13 digit ISBN number that starts with 978")
            txtTextbookID.Focus()
            Return False
        ElseIf txtAuthor.Text = "" Then
            MessageBox.Show("Please enter the author's last name")
            txtAuthor.Focus()
            Return False
        ElseIf txtTitle.Text = "" Then
            MessageBox.Show("Please enter the title of the textbook")
            txtTitle.Focus()
            Return False
        ElseIf txtPublisher.Text = "" Then
            MessageBox.Show("Please enter the publisher for the textbook")
            txtPublisher.Focus()
            Return False
        ElseIf txtCost.Text = "" Or IsNumeric(txtCost.Text) = False Then
            MessageBox.Show("Please enter the cost of the textbook")
            txtCost.Focus()
            Return False
        End If
        Return True
    End Function

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnEditTextbook_Click(sender As Object, e As EventArgs) Handles btnEditTextbook.Click
        If dataok() Then
            Dim db As New TextbooksDataContext
            Dim dgvIndex As Integer
            Dim textID As String
            dgvIndex = frmTextbook.dgvTextbooks.CurrentRow.Index
            textID = frmTextbook.dgvTextbooks.Rows(dgvIndex).Cells(0).Value.ToString
            Dim query = From text In db.tblTextbooks
                        Where text.TextbookID = textID
                        Select text

            For Each text As tblTextbook In query
                text.TextbookID = txtTextbookID.Text
                text.Author = txtAuthor.Text
                text.Title = txtTitle.Text
                text.Publisher = txtPublisher.Text
                text.Cost = CDbl(txtCost.Text)
            Next
            Try
                db.SubmitChanges()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            Me.Close()
        End If
    End Sub
End Class