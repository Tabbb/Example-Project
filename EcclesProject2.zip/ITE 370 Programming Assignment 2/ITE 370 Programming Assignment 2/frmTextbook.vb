﻿Public Class frmTextbook
    'Programmed by Brittany Eccles
    Private db As New TextbooksDataContext
    Private Sub frmTextbook_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim query = From atextbook In db.tblTextbooks
                    Order By atextbook.Author
                    Select atextbook.TextbookID, atextbook.Author, atextbook.Title, atextbook.Publisher, atextbook.Cost

        dgvTextbooks.DataSource = query
    End Sub

    Private Sub btnReturntoCourse_Click(sender As Object, e As EventArgs) Handles btnReturntoCourse.Click
        Me.Close()
    End Sub

    Private Sub btnDisplayAll_Click(sender As Object, e As EventArgs) Handles btnDisplayAll.Click
        Dim query = From atextbook In db.tblTextbooks
                    Order By atextbook.Author
                    Select atextbook.TextbookID, atextbook.Author, atextbook.Title, atextbook.Publisher, atextbook.Cost

        dgvTextbooks.DataSource = query
    End Sub

    Private Sub btnAddTextbook_Click(sender As Object, e As EventArgs) Handles btnAddTextbook.Click
        frmAddTextbook.ShowDialog()
        Dim query = From atextbook In db.tblTextbooks
                    Order By atextbook.Author
                    Select atextbook.TextbookID, atextbook.Author, atextbook.Title, atextbook.Publisher, atextbook.Cost

        dgvTextbooks.DataSource = query
    End Sub

    Private Sub btnDeleteTextbook_Click(sender As Object, e As EventArgs) Handles btnDeleteTextbook.Click
        Dim db As New TextbooksDataContext
        Dim result As Integer = MessageBox.Show("Are you sure you would like to delete this course?", "Attention", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            Dim dgvIndex As Integer
            Dim textID As String
            dgvIndex = dgvTextbooks.CurrentRow.Index
            textID = dgvTextbooks.Rows(dgvIndex).Cells(0).Value
            Dim query = From details In db.tblTextbooks
                        Where details.TextbookID = textID
                        Select details
            For Each detail In query
                db.tblTextbooks.DeleteOnSubmit(detail)
            Next
            Try
                db.SubmitChanges()
                MessageBox.Show("Textbook has successfully been deleted")
            Catch ex As Exception
                MessageBox.Show("You must delete all courses that have this textbook before deleting this textbook" & vbNewLine & vbNewLine & ex.Message)
            End Try
            Dim query2 = From atextbook In db.tblTextbooks
                         Order By atextbook.Author
                         Select atextbook.TextbookID, atextbook.Author, atextbook.Title, atextbook.Publisher, atextbook.Cost

            dgvTextbooks.DataSource = query2
        End If
    End Sub

    Private Sub btnEditTextbook_Click(sender As Object, e As EventArgs) Handles btnEditTextbook.Click
        frmEditTextbook.ShowDialog()
        Dim query = From atextbook In db.tblTextbooks
                    Order By atextbook.Author
                    Select atextbook.TextbookID, atextbook.Author, atextbook.Title, atextbook.Publisher, atextbook.Cost

        dgvTextbooks.DataSource = query
    End Sub

    Private Sub btnSearchTextbook_Click(sender As Object, e As EventArgs) Handles btnSearchTextbook.Click
        Dim input As String = InputBox("Please enter the 13-digit ISBN number of the textbook you would like to search for")
        Dim query = From atextbook In db.tblTextbooks
                    Where atextbook.TextbookID = input
                    Select atextbook.TextbookID, atextbook.Author, atextbook.Title, atextbook.Publisher, atextbook.Cost

        dgvTextbooks.DataSource = query
    End Sub

    Private Sub DisplayAllTextbooksToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DisplayAllTextbooksToolStripMenuItem.Click
        Dim query = From atextbook In db.tblTextbooks
                    Order By atextbook.Author
                    Select atextbook.TextbookID, atextbook.Author, atextbook.Title, atextbook.Publisher, atextbook.Cost

        dgvTextbooks.DataSource = query
    End Sub

    Private Sub AddTextbookToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddTextbookToolStripMenuItem.Click
        frmAddTextbook.ShowDialog()
        Dim query = From atextbook In db.tblTextbooks
                    Order By atextbook.Author
                    Select atextbook.TextbookID, atextbook.Author, atextbook.Title, atextbook.Publisher, atextbook.Cost

        dgvTextbooks.DataSource = query
    End Sub

    Private Sub DeleteTextbookToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteTextbookToolStripMenuItem.Click
        Dim db As New TextbooksDataContext
        Dim result As Integer = MessageBox.Show("Are you sure you would like to delete this course?", "Attention", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            Dim dgvIndex As Integer
            Dim textID As String
            dgvIndex = dgvTextbooks.CurrentRow.Index
            textID = dgvTextbooks.Rows(dgvIndex).Cells(0).Value
            Dim query = From details In db.tblTextbooks
                        Where details.TextbookID = textID
                        Select details
            For Each detail In query
                db.tblTextbooks.DeleteOnSubmit(detail)
            Next
            Try
                db.SubmitChanges()
                MessageBox.Show("Textbook has successfully been deleted")
            Catch ex As Exception
                MessageBox.Show("You must delete all courses that have this textbook before deleting this textbook" & vbNewLine & vbNewLine & ex.Message)
            End Try
            Dim query2 = From atextbook In db.tblTextbooks
                         Order By atextbook.Author
                         Select atextbook.TextbookID, atextbook.Author, atextbook.Title, atextbook.Publisher, atextbook.Cost

            dgvTextbooks.DataSource = query2
        End If
    End Sub

    Private Sub EditTextbookToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditTextbookToolStripMenuItem.Click
        frmEditTextbook.ShowDialog()
        Dim query = From atextbook In db.tblTextbooks
                    Order By atextbook.Author
                    Select atextbook.TextbookID, atextbook.Author, atextbook.Title, atextbook.Publisher, atextbook.Cost

        dgvTextbooks.DataSource = query
    End Sub
    Private Sub SearchForTextbookToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchForTextbookToolStripMenuItem.Click
        Dim input As String = InputBox("Please enter the 13-digit ISBN number of the textbook you would like to search for")
        Dim query = From atextbook In db.tblTextbooks
                    Where atextbook.TextbookID = input
                    Select atextbook.TextbookID, atextbook.Author, atextbook.Title, atextbook.Publisher, atextbook.Cost

        dgvTextbooks.DataSource = query
    End Sub
End Class