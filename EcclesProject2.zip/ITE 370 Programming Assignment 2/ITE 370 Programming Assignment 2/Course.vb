﻿Public Class Course
    'Programmed by Brittany Eccles
    Private adapter1 As New Project2DataSetTableAdapters.QueriesTableAdapter
    Private adapter2 As New Project2DataSetTableAdapters.tblCourseTableAdapter
    Private m_CourseID As Integer
    Private m_Instructor As String
    Private m_Semester As String
    Private m_StudentCnt As Integer
    Private m_TextbookID As String
    Public Property CourseID() As Integer
        Get
            Return m_CourseID
        End Get
        Set(value As Integer)
            value = m_CourseID
        End Set
    End Property
    Public Property Instructor() As String
        Get
            Return m_Instructor
        End Get
        Set(value As String)
            value = m_Instructor
        End Set
    End Property
    Public Property Semester() As String
        Get
            Return m_Semester
        End Get
        Set(value As String)
            value = m_Semester
        End Set
    End Property
    Public Property StudentCnt() As Integer
        Get
            Return m_StudentCnt
        End Get
        Set(value As Integer)
            value = StudentCnt
        End Set
    End Property
    Public Property TextbookID() As String
        Get
            Return m_TextbookID
        End Get
        Set(value As String)
            value = m_TextbookID
        End Set
    End Property
    Public ReadOnly Property item As DataTable
        Get
            Dim table As DataTable = adapter2.GetData()
            Return table
        End Get
    End Property
    Public Sub New()
        m_CourseID = 0
        m_Instructor = "Professor"
        m_Semester = "201600"
        m_StudentCnt = 0
        m_TextbookID = "9780000000000"
    End Sub
    Public Sub New(ByVal p_CourseID As Integer, ByVal p_Instructor As String, ByVal p_Semester As String, ByVal p_StudentCnt As Integer, ByVal p_TextbookID As String)
        m_CourseID = p_CourseID
        m_Instructor = p_Instructor
        m_Semester = p_Semester
        m_StudentCnt = p_StudentCnt
        m_TextbookID = p_TextbookID
    End Sub
    Public Overrides Function ToString() As String
        Return m_CourseID & " with the instructor " & m_Instructor & " during " & m_Semester & " semester needs " & m_StudentCnt & " of the textbook " & m_TextbookID
    End Function

    Public Function add(ByVal p_Instructor As String, ByVal p_Semester As String, ByVal p_StudentCnt As Integer, ByVal p_textbookID As String) As Boolean
        Return adapter1.AddCourse(p_Instructor, p_Semester, p_StudentCnt, p_textbookID) > 0
    End Function
    Public Function delete(ByVal p_CourseID As Integer) As Boolean
        Return adapter1.DeleteCourse(p_CourseID) > 0
    End Function
    Public Function find(ByVal p_instructor As String) As DataTable
        Return adapter2.GetDataByCourseInstructor(p_instructor)
    End Function
    Public Function update(ByVal p_instructor As String, ByVal p_semester As String, ByVal p_studentcnt As Integer, ByVal p_textbookID As String, ByVal p_courseid As Integer) As Boolean
        Return adapter1.UpdateCourse(p_instructor, p_semester, p_studentcnt, p_textbookID, p_courseid) > 0
    End Function
End Class
