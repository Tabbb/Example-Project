﻿Public Class frmCourse
    'Programmed by Brittany Eccles
    Private thecourse As New Course
    Private Sub frmCourse_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dgvCourse.DataSource = thecourse.item
    End Sub

    Private Sub btnAddCourse_Click(sender As Object, e As EventArgs) Handles btnAddCourse.Click
        frmAddCourse.ShowDialog()
        dgvCourse.DataSource = thecourse.item
    End Sub

    Private Sub btnDeleteCourse_Click(sender As Object, e As EventArgs) Handles btnDeleteCourse.Click
        Dim result As Integer = MessageBox.Show("Are you sure you would like to delete this course?", "Attention", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            Dim dgvIndex As Integer '
            Dim courseID As String
            dgvIndex = dgvCourse.CurrentRow.Index
            courseID = dgvCourse.Rows(dgvIndex).Cells(0).Value
            Try
                thecourse.delete(courseID)
                MessageBox.Show("Course was successfully deleted")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
        dgvCourse.DataSource = thecourse.item
    End Sub

    Private Sub btnEditCourse_Click(sender As Object, e As EventArgs) Handles btnEditCourse.Click
        frmEditCourse.ShowDialog()
        dgvCourse.DataSource = thecourse.item
    End Sub

    Private Sub btnSearchCourse_Click(sender As Object, e As EventArgs) Handles btnSearchCourse.Click
        Dim input As String = InputBox("Please enter the instructor's last name to search for")
        Try
            thecourse.find(input)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        dgvCourse.DataSource = thecourse.find(input)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplayTextbook_Click(sender As Object, e As EventArgs) Handles btnDisplayTextbook.Click
        frmTextbook.ShowDialog()
    End Sub

    Private Sub DisplayAllTextbooksToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DisplayAllTextbooksToolStripMenuItem.Click
        dgvCourse.DataSource = thecourse.item
    End Sub

    Private Sub AddCourseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddCourseToolStripMenuItem.Click
        frmAddCourse.ShowDialog()
        dgvCourse.DataSource = thecourse.item
    End Sub

    Private Sub DeleteCourseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteCourseToolStripMenuItem.Click
        Dim result As Integer = MessageBox.Show("Are you sure you would like to delete this course?", "Attention", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            Dim dgvIndex As Integer '
            Dim courseID As String
            dgvIndex = dgvCourse.CurrentRow.Index
            courseID = dgvCourse.Rows(dgvIndex).Cells(0).Value
            Try
                thecourse.delete(courseID)
                MessageBox.Show("Course was successfully deleted")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
        dgvCourse.DataSource = thecourse.item
    End Sub

    Private Sub EditCourseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditCourseToolStripMenuItem.Click
        frmEditCourse.ShowDialog()
        dgvCourse.DataSource = thecourse.item
    End Sub

    Private Sub SearchForCourseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchForCourseToolStripMenuItem.Click
        Dim input As String = InputBox("Please enter the instructor's last name to search for")
        Try
            thecourse.find(input)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnDisplayCourses_Click(sender As Object, e As EventArgs) Handles btnDisplayCourses.Click
        dgvCourse.DataSource = thecourse.item
    End Sub

    Private Sub btnDisplayReports_Click(sender As Object, e As EventArgs) Handles btnDisplayReports.Click
        frmReports.ShowDialog()
    End Sub
End Class
