﻿Public Class frmEditCourse
    'Programmed by Brittany Eccles
    Private thecourse As New Course
    Private Sub EditCourse_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dgvindex As Integer
        dgvindex = frmCourse.dgvCourse.CurrentRow.Index
        txtCourseID.Text = frmCourse.dgvCourse.Rows(dgvindex).Cells(0).Value
        txtInstructor.Text = frmCourse.dgvCourse.Rows(dgvindex).Cells(1).Value
        txtSemester.Text = frmCourse.dgvCourse.Rows(dgvindex).Cells(2).Value
        txtStudentCnt.Text = frmCourse.dgvCourse.Rows(dgvindex).Cells(3).Value
        txtTextbook.Text = frmCourse.dgvCourse.Rows(dgvindex).Cells(4).Value
        txtInstructor.Focus()
    End Sub
    Function dataok() As Boolean
        If txtInstructor.Text = "" Then
            MessageBox.Show("Please enter the instructor's name")
            txtInstructor.Focus()
            Return False
        ElseIf txtSemester.Text = "" Or IsNumeric(txtSemester.Text) = False Or Len(txtSemester.Text) <> 6 Then
            MessageBox.Show("Please enter the correct semester")
            txtSemester.Text = ""
            txtSemester.Focus()
            Return False
        ElseIf txtStudentCnt.Text = "" Or IsNumeric(txtStudentCnt.Text) = False Then
            MessageBox.Show("Please enter the student count for the class")
            txtStudentCnt.Text = ""
            txtStudentCnt.Focus()
            Return False
        ElseIf txtTextbook.Text = "" Or Len(txtTextbook.Text) <> 13 Then
            MessageBox.Show("Please enter the 13 digit ISBN number")
            txtTextbook.Focus()
            Return False
        ElseIf txtTextbook.Text.Substring(0, 3) <> "978" Then
            MessageBox.Show("Please enter the number 13 digit ISBN number that starts with 978")
            txtTextbook.Focus()
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub btnEditCourse_Click(sender As Object, e As EventArgs) Handles btnEditCourse.Click
        If dataok() Then
            Try
                thecourse.update(txtInstructor.Text, txtSemester.Text, CInt(txtStudentCnt.Text), txtTextbook.Text, CInt(txtCourseID.Text))
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
        Me.Close()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class