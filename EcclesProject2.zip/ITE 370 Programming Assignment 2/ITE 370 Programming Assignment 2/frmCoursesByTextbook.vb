﻿Public Class frmCoursesByTextbook
    Private Sub frmCoursesByTextbook_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Project2DataSet.tblCourse' table. You can move, or remove it, as needed.
        Me.tblCourseTableAdapter.Fill(Me.Project2DataSet.tblCourse)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class