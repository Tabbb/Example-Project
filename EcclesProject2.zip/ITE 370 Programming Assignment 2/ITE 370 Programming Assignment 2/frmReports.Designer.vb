﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReports
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDisplayAllTextbooks = New System.Windows.Forms.Button()
        Me.btnAllCourses = New System.Windows.Forms.Button()
        Me.btnCoursesbySemester = New System.Windows.Forms.Button()
        Me.btnCoursesbyTextbooks = New System.Windows.Forms.Button()
        Me.btnTextbooksMinMax = New System.Windows.Forms.Button()
        Me.btnReturnToCourses = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnDisplayAllTextbooks
        '
        Me.btnDisplayAllTextbooks.Location = New System.Drawing.Point(21, 12)
        Me.btnDisplayAllTextbooks.Name = "btnDisplayAllTextbooks"
        Me.btnDisplayAllTextbooks.Size = New System.Drawing.Size(163, 53)
        Me.btnDisplayAllTextbooks.TabIndex = 0
        Me.btnDisplayAllTextbooks.Text = "All Textbooks"
        Me.btnDisplayAllTextbooks.UseVisualStyleBackColor = True
        '
        'btnAllCourses
        '
        Me.btnAllCourses.Location = New System.Drawing.Point(198, 12)
        Me.btnAllCourses.Name = "btnAllCourses"
        Me.btnAllCourses.Size = New System.Drawing.Size(163, 53)
        Me.btnAllCourses.TabIndex = 1
        Me.btnAllCourses.Text = "All Courses"
        Me.btnAllCourses.UseVisualStyleBackColor = True
        '
        'btnCoursesbySemester
        '
        Me.btnCoursesbySemester.Location = New System.Drawing.Point(21, 71)
        Me.btnCoursesbySemester.Name = "btnCoursesbySemester"
        Me.btnCoursesbySemester.Size = New System.Drawing.Size(163, 53)
        Me.btnCoursesbySemester.TabIndex = 2
        Me.btnCoursesbySemester.Text = "Courses by Semester"
        Me.btnCoursesbySemester.UseVisualStyleBackColor = True
        '
        'btnCoursesbyTextbooks
        '
        Me.btnCoursesbyTextbooks.Location = New System.Drawing.Point(198, 71)
        Me.btnCoursesbyTextbooks.Name = "btnCoursesbyTextbooks"
        Me.btnCoursesbyTextbooks.Size = New System.Drawing.Size(163, 53)
        Me.btnCoursesbyTextbooks.TabIndex = 3
        Me.btnCoursesbyTextbooks.Text = "Courses by Textbooks"
        Me.btnCoursesbyTextbooks.UseVisualStyleBackColor = True
        '
        'btnTextbooksMinMax
        '
        Me.btnTextbooksMinMax.Location = New System.Drawing.Point(21, 130)
        Me.btnTextbooksMinMax.Name = "btnTextbooksMinMax"
        Me.btnTextbooksMinMax.Size = New System.Drawing.Size(163, 53)
        Me.btnTextbooksMinMax.TabIndex = 4
        Me.btnTextbooksMinMax.Text = "Textbooks with Min and Max"
        Me.btnTextbooksMinMax.UseVisualStyleBackColor = True
        '
        'btnReturnToCourses
        '
        Me.btnReturnToCourses.Location = New System.Drawing.Point(198, 131)
        Me.btnReturnToCourses.Name = "btnReturnToCourses"
        Me.btnReturnToCourses.Size = New System.Drawing.Size(162, 51)
        Me.btnReturnToCourses.TabIndex = 5
        Me.btnReturnToCourses.Text = "Return to Main Form"
        Me.btnReturnToCourses.UseVisualStyleBackColor = True
        '
        'frmReports
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(390, 208)
        Me.Controls.Add(Me.btnReturnToCourses)
        Me.Controls.Add(Me.btnTextbooksMinMax)
        Me.Controls.Add(Me.btnCoursesbyTextbooks)
        Me.Controls.Add(Me.btnCoursesbySemester)
        Me.Controls.Add(Me.btnAllCourses)
        Me.Controls.Add(Me.btnDisplayAllTextbooks)
        Me.Name = "frmReports"
        Me.Text = "Reports"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnDisplayAllTextbooks As Button
    Friend WithEvents btnAllCourses As Button
    Friend WithEvents btnCoursesbySemester As Button
    Friend WithEvents btnCoursesbyTextbooks As Button
    Friend WithEvents btnTextbooksMinMax As Button
    Friend WithEvents btnReturnToCourses As Button
End Class
