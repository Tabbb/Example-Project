﻿Public Class frmTextbooksWithMinandMax
    Private Sub frmTextbooksWithMinandMax_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TextbookDataSet.tblTextbook' table. You can move, or remove it, as needed.
        Me.tblTextbookTableAdapter.Fill(Me.TextbookDataSet.tblTextbook)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class