﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmTextbook
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.dgvTextbooks = New System.Windows.Forms.DataGridView()
        Me.btnAddTextbook = New System.Windows.Forms.Button()
        Me.btnDeleteTextbook = New System.Windows.Forms.Button()
        Me.btnEditTextbook = New System.Windows.Forms.Button()
        Me.btnSearchTextbook = New System.Windows.Forms.Button()
        Me.btnDisplayAll = New System.Windows.Forms.Button()
        Me.btnReturntoCourse = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.DisplayAllTextbooksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddTextbookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteTextbookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditTextbookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchForTextbookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.dgvTextbooks, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvTextbooks
        '
        Me.dgvTextbooks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvTextbooks.Location = New System.Drawing.Point(12, 41)
        Me.dgvTextbooks.Name = "dgvTextbooks"
        Me.dgvTextbooks.RowTemplate.Height = 24
        Me.dgvTextbooks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvTextbooks.Size = New System.Drawing.Size(667, 251)
        Me.dgvTextbooks.TabIndex = 0
        '
        'btnAddTextbook
        '
        Me.btnAddTextbook.Location = New System.Drawing.Point(258, 307)
        Me.btnAddTextbook.Name = "btnAddTextbook"
        Me.btnAddTextbook.Size = New System.Drawing.Size(190, 46)
        Me.btnAddTextbook.TabIndex = 1
        Me.btnAddTextbook.Text = "Add Textbook"
        Me.btnAddTextbook.UseVisualStyleBackColor = True
        '
        'btnDeleteTextbook
        '
        Me.btnDeleteTextbook.Location = New System.Drawing.Point(476, 307)
        Me.btnDeleteTextbook.Name = "btnDeleteTextbook"
        Me.btnDeleteTextbook.Size = New System.Drawing.Size(190, 46)
        Me.btnDeleteTextbook.TabIndex = 2
        Me.btnDeleteTextbook.Text = "Delete Textbook"
        Me.btnDeleteTextbook.UseVisualStyleBackColor = True
        '
        'btnEditTextbook
        '
        Me.btnEditTextbook.Location = New System.Drawing.Point(47, 359)
        Me.btnEditTextbook.Name = "btnEditTextbook"
        Me.btnEditTextbook.Size = New System.Drawing.Size(189, 46)
        Me.btnEditTextbook.TabIndex = 3
        Me.btnEditTextbook.Text = "Edit Textbook"
        Me.btnEditTextbook.UseVisualStyleBackColor = True
        '
        'btnSearchTextbook
        '
        Me.btnSearchTextbook.Location = New System.Drawing.Point(258, 359)
        Me.btnSearchTextbook.Name = "btnSearchTextbook"
        Me.btnSearchTextbook.Size = New System.Drawing.Size(190, 46)
        Me.btnSearchTextbook.TabIndex = 4
        Me.btnSearchTextbook.Text = "Search for Textbook"
        Me.btnSearchTextbook.UseVisualStyleBackColor = True
        '
        'btnDisplayAll
        '
        Me.btnDisplayAll.Location = New System.Drawing.Point(47, 307)
        Me.btnDisplayAll.Name = "btnDisplayAll"
        Me.btnDisplayAll.Size = New System.Drawing.Size(189, 46)
        Me.btnDisplayAll.TabIndex = 5
        Me.btnDisplayAll.Text = "Display All Textbooks"
        Me.btnDisplayAll.UseVisualStyleBackColor = True
        '
        'btnReturntoCourse
        '
        Me.btnReturntoCourse.Location = New System.Drawing.Point(476, 359)
        Me.btnReturntoCourse.Name = "btnReturntoCourse"
        Me.btnReturntoCourse.Size = New System.Drawing.Size(190, 46)
        Me.btnReturntoCourse.TabIndex = 6
        Me.btnReturntoCourse.Text = "Return to Course Form"
        Me.btnReturntoCourse.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DisplayAllTextbooksToolStripMenuItem, Me.AddTextbookToolStripMenuItem, Me.DeleteTextbookToolStripMenuItem, Me.EditTextbookToolStripMenuItem, Me.SearchForTextbookToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(691, 28)
        Me.MenuStrip1.TabIndex = 7
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'DisplayAllTextbooksToolStripMenuItem
        '
        Me.DisplayAllTextbooksToolStripMenuItem.Name = "DisplayAllTextbooksToolStripMenuItem"
        Me.DisplayAllTextbooksToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.DisplayAllTextbooksToolStripMenuItem.Size = New System.Drawing.Size(163, 24)
        Me.DisplayAllTextbooksToolStripMenuItem.Text = "Display All &Textbooks"
        '
        'AddTextbookToolStripMenuItem
        '
        Me.AddTextbookToolStripMenuItem.Name = "AddTextbookToolStripMenuItem"
        Me.AddTextbookToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.AddTextbookToolStripMenuItem.Size = New System.Drawing.Size(114, 24)
        Me.AddTextbookToolStripMenuItem.Text = "&Add Textbook"
        '
        'DeleteTextbookToolStripMenuItem
        '
        Me.DeleteTextbookToolStripMenuItem.Name = "DeleteTextbookToolStripMenuItem"
        Me.DeleteTextbookToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.DeleteTextbookToolStripMenuItem.Size = New System.Drawing.Size(130, 24)
        Me.DeleteTextbookToolStripMenuItem.Text = "&Delete Textbook"
        '
        'EditTextbookToolStripMenuItem
        '
        Me.EditTextbookToolStripMenuItem.Name = "EditTextbookToolStripMenuItem"
        Me.EditTextbookToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.EditTextbookToolStripMenuItem.Size = New System.Drawing.Size(112, 24)
        Me.EditTextbookToolStripMenuItem.Text = "&Edit Textbook"
        '
        'SearchForTextbookToolStripMenuItem
        '
        Me.SearchForTextbookToolStripMenuItem.Name = "SearchForTextbookToolStripMenuItem"
        Me.SearchForTextbookToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SearchForTextbookToolStripMenuItem.Size = New System.Drawing.Size(153, 24)
        Me.SearchForTextbookToolStripMenuItem.Text = "&Search for Textbook"
        '
        'frmTextbook
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(691, 422)
        Me.Controls.Add(Me.btnReturntoCourse)
        Me.Controls.Add(Me.btnDisplayAll)
        Me.Controls.Add(Me.btnSearchTextbook)
        Me.Controls.Add(Me.btnEditTextbook)
        Me.Controls.Add(Me.btnDeleteTextbook)
        Me.Controls.Add(Me.btnAddTextbook)
        Me.Controls.Add(Me.dgvTextbooks)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmTextbook"
        Me.Text = "Textbook Form"
        CType(Me.dgvTextbooks, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvTextbooks As DataGridView
    Friend WithEvents btnAddTextbook As Button
    Friend WithEvents btnDeleteTextbook As Button
    Friend WithEvents btnEditTextbook As Button
    Friend WithEvents btnSearchTextbook As Button
    Friend WithEvents btnDisplayAll As Button
    Friend WithEvents btnReturntoCourse As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents DisplayAllTextbooksToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddTextbookToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeleteTextbookToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditTextbookToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchForTextbookToolStripMenuItem As ToolStripMenuItem
End Class
