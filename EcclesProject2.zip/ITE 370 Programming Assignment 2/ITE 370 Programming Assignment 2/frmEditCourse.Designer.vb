﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEditCourse
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtCourseID = New System.Windows.Forms.TextBox()
        Me.txtInstructor = New System.Windows.Forms.TextBox()
        Me.txtSemester = New System.Windows.Forms.TextBox()
        Me.txtStudentCnt = New System.Windows.Forms.TextBox()
        Me.txtTextbook = New System.Windows.Forms.TextBox()
        Me.lblCourseID = New System.Windows.Forms.Label()
        Me.lblInstructor = New System.Windows.Forms.Label()
        Me.lblSemester = New System.Windows.Forms.Label()
        Me.lblStudentCnt = New System.Windows.Forms.Label()
        Me.lblTextbook = New System.Windows.Forms.Label()
        Me.btnEditCourse = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtCourseID
        '
        Me.txtCourseID.Location = New System.Drawing.Point(221, 12)
        Me.txtCourseID.Name = "txtCourseID"
        Me.txtCourseID.ReadOnly = True
        Me.txtCourseID.Size = New System.Drawing.Size(82, 22)
        Me.txtCourseID.TabIndex = 0
        '
        'txtInstructor
        '
        Me.txtInstructor.Location = New System.Drawing.Point(221, 50)
        Me.txtInstructor.Name = "txtInstructor"
        Me.txtInstructor.Size = New System.Drawing.Size(169, 22)
        Me.txtInstructor.TabIndex = 1
        '
        'txtSemester
        '
        Me.txtSemester.Location = New System.Drawing.Point(221, 78)
        Me.txtSemester.Name = "txtSemester"
        Me.txtSemester.Size = New System.Drawing.Size(82, 22)
        Me.txtSemester.TabIndex = 2
        '
        'txtStudentCnt
        '
        Me.txtStudentCnt.Location = New System.Drawing.Point(221, 106)
        Me.txtStudentCnt.Name = "txtStudentCnt"
        Me.txtStudentCnt.Size = New System.Drawing.Size(82, 22)
        Me.txtStudentCnt.TabIndex = 3
        '
        'txtTextbook
        '
        Me.txtTextbook.Location = New System.Drawing.Point(221, 134)
        Me.txtTextbook.Name = "txtTextbook"
        Me.txtTextbook.Size = New System.Drawing.Size(169, 22)
        Me.txtTextbook.TabIndex = 4
        '
        'lblCourseID
        '
        Me.lblCourseID.AutoSize = True
        Me.lblCourseID.Location = New System.Drawing.Point(141, 15)
        Me.lblCourseID.Name = "lblCourseID"
        Me.lblCourseID.Size = New System.Drawing.Size(74, 17)
        Me.lblCourseID.TabIndex = 5
        Me.lblCourseID.Text = "Course ID:"
        '
        'lblInstructor
        '
        Me.lblInstructor.AutoSize = True
        Me.lblInstructor.Location = New System.Drawing.Point(62, 53)
        Me.lblInstructor.Name = "lblInstructor"
        Me.lblInstructor.Size = New System.Drawing.Size(153, 17)
        Me.lblInstructor.TabIndex = 6
        Me.lblInstructor.Text = "Instructor's Last Name:"
        '
        'lblSemester
        '
        Me.lblSemester.AutoSize = True
        Me.lblSemester.Location = New System.Drawing.Point(143, 81)
        Me.lblSemester.Name = "lblSemester"
        Me.lblSemester.Size = New System.Drawing.Size(72, 17)
        Me.lblSemester.TabIndex = 7
        Me.lblSemester.Text = "Semester:"
        '
        'lblStudentCnt
        '
        Me.lblStudentCnt.AutoSize = True
        Me.lblStudentCnt.Location = New System.Drawing.Point(113, 109)
        Me.lblStudentCnt.Name = "lblStudentCnt"
        Me.lblStudentCnt.Size = New System.Drawing.Size(102, 17)
        Me.lblStudentCnt.TabIndex = 8
        Me.lblStudentCnt.Text = "Student Count:"
        '
        'lblTextbook
        '
        Me.lblTextbook.AutoSize = True
        Me.lblTextbook.Location = New System.Drawing.Point(3, 137)
        Me.lblTextbook.Name = "lblTextbook"
        Me.lblTextbook.Size = New System.Drawing.Size(212, 17)
        Me.lblTextbook.TabIndex = 9
        Me.lblTextbook.Text = "Textbook ISBN 13-Digit Number:"
        '
        'btnEditCourse
        '
        Me.btnEditCourse.Location = New System.Drawing.Point(12, 178)
        Me.btnEditCourse.Name = "btnEditCourse"
        Me.btnEditCourse.Size = New System.Drawing.Size(169, 49)
        Me.btnEditCourse.TabIndex = 10
        Me.btnEditCourse.Text = "Edit Course"
        Me.btnEditCourse.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(221, 178)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(169, 49)
        Me.btnClose.TabIndex = 11
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'frmEditCourse
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(405, 239)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnEditCourse)
        Me.Controls.Add(Me.lblTextbook)
        Me.Controls.Add(Me.lblStudentCnt)
        Me.Controls.Add(Me.lblSemester)
        Me.Controls.Add(Me.lblInstructor)
        Me.Controls.Add(Me.lblCourseID)
        Me.Controls.Add(Me.txtTextbook)
        Me.Controls.Add(Me.txtStudentCnt)
        Me.Controls.Add(Me.txtSemester)
        Me.Controls.Add(Me.txtInstructor)
        Me.Controls.Add(Me.txtCourseID)
        Me.Name = "frmEditCourse"
        Me.Text = "Edit Course"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtCourseID As TextBox
    Friend WithEvents txtInstructor As TextBox
    Friend WithEvents txtSemester As TextBox
    Friend WithEvents txtStudentCnt As TextBox
    Friend WithEvents txtTextbook As TextBox
    Friend WithEvents lblCourseID As Label
    Friend WithEvents lblInstructor As Label
    Friend WithEvents lblSemester As Label
    Friend WithEvents lblStudentCnt As Label
    Friend WithEvents lblTextbook As Label
    Friend WithEvents btnEditCourse As Button
    Friend WithEvents btnClose As Button
End Class
