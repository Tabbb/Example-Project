﻿Public Class frmAddCourse
    'Programmed by Brittany Eccles
    Private thecourse As New Course
    Private Sub btnAddCourse_Click(sender As Object, e As EventArgs) Handles btnAddCourse.Click
        If dataok() Then
            Try
                thecourse.add(txtInstructor.Text, txtSemester.Text, CInt(txtStudentCnt.Text), txtTextbook.Text)
            Catch ex As Exception
                MessageBox.Show("You must create the textbook you are going to use for this course first. You can do this by going to the textbook form and adding this textbook" & vbNewLine & vbNewLine & ex.Message)
            End Try
            Me.Close()
        End If
    End Sub
    Function dataok() As Boolean
        If txtInstructor.Text = "" Then
            MessageBox.Show("Please enter the instructor's name")
            txtInstructor.Focus()
            Return False
        ElseIf txtSemester.Text = "" Or IsNumeric(txtSemester.Text) = False Or Len(txtSemester.Text) <> 6 Then
            MessageBox.Show("Please enter the correct semester (Example: 201610)")
            txtSemester.Text = ""
            txtSemester.Focus()
            Return False
        ElseIf txtStudentCnt.Text = "" Or IsNumeric(txtStudentCnt.Text) = False Then
            MessageBox.Show("Please enter the student count for the class")
            txtStudentCnt.Text = ""
            txtStudentCnt.Focus()
            Return False
        ElseIf txtTextbook.Text = "" Or Len(txtTextbook.Text) <> 13 Then
            MessageBox.Show("Please enter the 13 digit ISBN number")
            txtTextbook.Focus()
            Return False
        ElseIf txtTextbook.Text.Substring(0, 3) <> "978" Then
            MessageBox.Show("Please enter the number 13 digit ISBN number that starts with 978")
            txtTextbook.Focus()
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub frmAddCourse_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtSemester.Text = ""
        txtInstructor.Text = ""
        txtStudentCnt.Text = ""
        txtTextbook.Text = ""
        txtInstructor.Focus()
    End Sub
End Class