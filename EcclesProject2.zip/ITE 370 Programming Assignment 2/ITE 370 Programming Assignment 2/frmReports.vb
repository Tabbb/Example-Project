﻿Public Class frmReports
    'Programmed by Brittany Eccles
    Private Sub btnDisplayAllTextbooks_Click(sender As Object, e As EventArgs) Handles btnDisplayAllTextbooks.Click
        frmAllTextbooksReport.ShowDialog()
    End Sub

    Private Sub btnAllCourses_Click(sender As Object, e As EventArgs) Handles btnAllCourses.Click
        AllCoursesReport.ShowDialog()
    End Sub

    Private Sub btnCoursesbySemester_Click(sender As Object, e As EventArgs) Handles btnCoursesbySemester.Click
        frmCoursesBySemester.ShowDialog()
    End Sub

    Private Sub btnCoursesbyTextbooks_Click(sender As Object, e As EventArgs) Handles btnCoursesbyTextbooks.Click
        frmCoursesByTextbook.ShowDialog()
    End Sub

    Private Sub btnTextbooksMinMax_Click(sender As Object, e As EventArgs) Handles btnTextbooksMinMax.Click
        frmTextbooksWithMinandMax.ShowDialog()
    End Sub

    Private Sub btnReturnToCourses_Click(sender As Object, e As EventArgs) Handles btnReturnToCourses.Click
        Me.Close()
    End Sub
End Class