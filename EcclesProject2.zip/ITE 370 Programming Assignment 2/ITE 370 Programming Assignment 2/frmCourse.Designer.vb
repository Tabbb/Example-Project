﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCourse
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvCourse = New System.Windows.Forms.DataGridView()
        Me.btnAddCourse = New System.Windows.Forms.Button()
        Me.btnDeleteCourse = New System.Windows.Forms.Button()
        Me.btnEditCourse = New System.Windows.Forms.Button()
        Me.btnSearchCourse = New System.Windows.Forms.Button()
        Me.btnDisplayTextbook = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnDisplayCourses = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.DisplayAllTextbooksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddCourseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteCourseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditCourseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchForCourseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnDisplayReports = New System.Windows.Forms.Button()
        CType(Me.dgvCourse, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvCourse
        '
        Me.dgvCourse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCourse.Location = New System.Drawing.Point(8, 45)
        Me.dgvCourse.Name = "dgvCourse"
        Me.dgvCourse.RowTemplate.Height = 24
        Me.dgvCourse.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvCourse.Size = New System.Drawing.Size(691, 283)
        Me.dgvCourse.TabIndex = 0
        '
        'btnAddCourse
        '
        Me.btnAddCourse.Location = New System.Drawing.Point(245, 345)
        Me.btnAddCourse.Name = "btnAddCourse"
        Me.btnAddCourse.Size = New System.Drawing.Size(220, 45)
        Me.btnAddCourse.TabIndex = 1
        Me.btnAddCourse.Text = "Add Course"
        Me.btnAddCourse.UseVisualStyleBackColor = True
        '
        'btnDeleteCourse
        '
        Me.btnDeleteCourse.Location = New System.Drawing.Point(489, 345)
        Me.btnDeleteCourse.Name = "btnDeleteCourse"
        Me.btnDeleteCourse.Size = New System.Drawing.Size(188, 45)
        Me.btnDeleteCourse.TabIndex = 2
        Me.btnDeleteCourse.Text = "Delete Course"
        Me.btnDeleteCourse.UseVisualStyleBackColor = True
        '
        'btnEditCourse
        '
        Me.btnEditCourse.Location = New System.Drawing.Point(32, 396)
        Me.btnEditCourse.Name = "btnEditCourse"
        Me.btnEditCourse.Size = New System.Drawing.Size(195, 45)
        Me.btnEditCourse.TabIndex = 3
        Me.btnEditCourse.Text = "Edit Course"
        Me.btnEditCourse.UseVisualStyleBackColor = True
        '
        'btnSearchCourse
        '
        Me.btnSearchCourse.Location = New System.Drawing.Point(245, 396)
        Me.btnSearchCourse.Name = "btnSearchCourse"
        Me.btnSearchCourse.Size = New System.Drawing.Size(220, 45)
        Me.btnSearchCourse.TabIndex = 4
        Me.btnSearchCourse.Text = "Search for Course"
        Me.btnSearchCourse.UseVisualStyleBackColor = True
        '
        'btnDisplayTextbook
        '
        Me.btnDisplayTextbook.Location = New System.Drawing.Point(32, 457)
        Me.btnDisplayTextbook.Name = "btnDisplayTextbook"
        Me.btnDisplayTextbook.Size = New System.Drawing.Size(322, 45)
        Me.btnDisplayTextbook.TabIndex = 5
        Me.btnDisplayTextbook.Text = "Display Textbook Form"
        Me.btnDisplayTextbook.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(489, 396)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(188, 45)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnDisplayCourses
        '
        Me.btnDisplayCourses.Location = New System.Drawing.Point(32, 345)
        Me.btnDisplayCourses.Name = "btnDisplayCourses"
        Me.btnDisplayCourses.Size = New System.Drawing.Size(195, 45)
        Me.btnDisplayCourses.TabIndex = 7
        Me.btnDisplayCourses.Text = "Display All Courses"
        Me.btnDisplayCourses.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DisplayAllTextbooksToolStripMenuItem, Me.AddCourseToolStripMenuItem, Me.DeleteCourseToolStripMenuItem, Me.EditCourseToolStripMenuItem, Me.SearchForCourseToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(708, 28)
        Me.MenuStrip1.TabIndex = 8
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'DisplayAllTextbooksToolStripMenuItem
        '
        Me.DisplayAllTextbooksToolStripMenuItem.Name = "DisplayAllTextbooksToolStripMenuItem"
        Me.DisplayAllTextbooksToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.DisplayAllTextbooksToolStripMenuItem.Size = New System.Drawing.Size(147, 24)
        Me.DisplayAllTextbooksToolStripMenuItem.Text = "Display All &Courses"
        '
        'AddCourseToolStripMenuItem
        '
        Me.AddCourseToolStripMenuItem.Name = "AddCourseToolStripMenuItem"
        Me.AddCourseToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.AddCourseToolStripMenuItem.Size = New System.Drawing.Size(98, 24)
        Me.AddCourseToolStripMenuItem.Text = "&Add Course"
        '
        'DeleteCourseToolStripMenuItem
        '
        Me.DeleteCourseToolStripMenuItem.Name = "DeleteCourseToolStripMenuItem"
        Me.DeleteCourseToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.DeleteCourseToolStripMenuItem.Size = New System.Drawing.Size(114, 24)
        Me.DeleteCourseToolStripMenuItem.Text = "&Delete Course"
        '
        'EditCourseToolStripMenuItem
        '
        Me.EditCourseToolStripMenuItem.Name = "EditCourseToolStripMenuItem"
        Me.EditCourseToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.EditCourseToolStripMenuItem.Size = New System.Drawing.Size(96, 24)
        Me.EditCourseToolStripMenuItem.Text = "&Edit Course"
        '
        'SearchForCourseToolStripMenuItem
        '
        Me.SearchForCourseToolStripMenuItem.Name = "SearchForCourseToolStripMenuItem"
        Me.SearchForCourseToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SearchForCourseToolStripMenuItem.Size = New System.Drawing.Size(137, 24)
        Me.SearchForCourseToolStripMenuItem.Text = "&Search for Course"
        '
        'btnDisplayReports
        '
        Me.btnDisplayReports.Location = New System.Drawing.Point(365, 457)
        Me.btnDisplayReports.Name = "btnDisplayReports"
        Me.btnDisplayReports.Size = New System.Drawing.Size(312, 44)
        Me.btnDisplayReports.TabIndex = 9
        Me.btnDisplayReports.Text = "Display Reports"
        Me.btnDisplayReports.UseVisualStyleBackColor = True
        '
        'frmCourse
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(708, 514)
        Me.Controls.Add(Me.btnDisplayReports)
        Me.Controls.Add(Me.btnDisplayCourses)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnDisplayTextbook)
        Me.Controls.Add(Me.btnSearchCourse)
        Me.Controls.Add(Me.btnEditCourse)
        Me.Controls.Add(Me.btnDeleteCourse)
        Me.Controls.Add(Me.btnAddCourse)
        Me.Controls.Add(Me.dgvCourse)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmCourse"
        Me.Text = "Course Form"
        CType(Me.dgvCourse, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvCourse As DataGridView
    Friend WithEvents btnAddCourse As Button
    Friend WithEvents btnDeleteCourse As Button
    Friend WithEvents btnEditCourse As Button
    Friend WithEvents btnSearchCourse As Button
    Friend WithEvents btnDisplayTextbook As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnDisplayCourses As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents DisplayAllTextbooksToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddCourseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeleteCourseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditCourseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchForCourseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnDisplayReports As Button
End Class
