﻿Public Class frmAddTextbook
    Private db As New TextbooksDataContext
    Private Sub btnAddTextbook_Click(sender As Object, e As EventArgs) Handles btnAddTextbook.Click
        If dataok() Then
            Dim cost, rounded As Double
            cost = CDbl(txtCost.Text)
            rounded = Math.Round(cost, 2)
            Dim text As New tblTextbook With {.TextbookID = txtTextbookID.Text, .Author = txtAuthor.Text, .Title = txtTitle.Text, .Publisher = txtPublisher.Text, .Cost = rounded}
            db.tblTextbooks.InsertOnSubmit(text)
            Try
                db.SubmitChanges()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            Me.Close()
        End If
    End Sub
    Function dataok() As Boolean
        If txtTextbookID.Text = "" Or Len(txtTextbookID.Text) <> 13 Then
            MessageBox.Show("Please enter the 13 digit ISBN number")
            txtTextbookID.Focus()
            Return False
        ElseIf txtTextbookID.Text.Substring(0, 3) <> "978" Then
            MessageBox.Show("Please enter the number 13 digit ISBN number that starts with 978")
            txtTextbookID.Focus()
            Return False
        ElseIf txtAuthor.Text = "" Then
            MessageBox.Show("Please enter the author's last name")
            txtAuthor.Focus()
            Return False
        ElseIf txtTitle.Text = "" Then
            MessageBox.Show("Please enter the title of the textbook")
            txtTitle.Focus()
            Return False
        ElseIf txtPublisher.Text = "" Then
            MessageBox.Show("Please enter the publisher for the textbook")
            txtPublisher.Focus()
            Return False
        ElseIf txtCost.Text = "" Or IsNumeric(txtCost.Text) = False Then
            MessageBox.Show("Please enter the cost of the textbook")
            txtCost.Focus()
            Return False
        End If
        Return True
    End Function

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub frmAddTextbook_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtAuthor.Text = ""
        txtTitle.Text = ""
        txtCost.Text = ""
        txtPublisher.Text = ""
        txtTextbookID.Text = ""
        txtTextbookID.Focus()
    End Sub
End Class