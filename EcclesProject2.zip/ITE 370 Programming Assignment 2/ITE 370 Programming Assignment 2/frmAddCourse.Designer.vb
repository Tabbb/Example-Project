﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddCourse
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtInstructor = New System.Windows.Forms.TextBox()
        Me.txtSemester = New System.Windows.Forms.TextBox()
        Me.txtStudentCnt = New System.Windows.Forms.TextBox()
        Me.txtTextbook = New System.Windows.Forms.TextBox()
        Me.lblInstructor = New System.Windows.Forms.Label()
        Me.lblSemester = New System.Windows.Forms.Label()
        Me.lblStudentCnt = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnAddCourse = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtInstructor
        '
        Me.txtInstructor.Location = New System.Drawing.Point(218, 26)
        Me.txtInstructor.Name = "txtInstructor"
        Me.txtInstructor.Size = New System.Drawing.Size(176, 22)
        Me.txtInstructor.TabIndex = 0
        '
        'txtSemester
        '
        Me.txtSemester.Location = New System.Drawing.Point(218, 54)
        Me.txtSemester.Name = "txtSemester"
        Me.txtSemester.Size = New System.Drawing.Size(96, 22)
        Me.txtSemester.TabIndex = 1
        '
        'txtStudentCnt
        '
        Me.txtStudentCnt.Location = New System.Drawing.Point(218, 82)
        Me.txtStudentCnt.Name = "txtStudentCnt"
        Me.txtStudentCnt.Size = New System.Drawing.Size(96, 22)
        Me.txtStudentCnt.TabIndex = 2
        '
        'txtTextbook
        '
        Me.txtTextbook.Location = New System.Drawing.Point(218, 110)
        Me.txtTextbook.Name = "txtTextbook"
        Me.txtTextbook.Size = New System.Drawing.Size(176, 22)
        Me.txtTextbook.TabIndex = 3
        '
        'lblInstructor
        '
        Me.lblInstructor.AutoSize = True
        Me.lblInstructor.Location = New System.Drawing.Point(59, 29)
        Me.lblInstructor.Name = "lblInstructor"
        Me.lblInstructor.Size = New System.Drawing.Size(153, 17)
        Me.lblInstructor.TabIndex = 4
        Me.lblInstructor.Text = "Instructor's Last Name:"
        '
        'lblSemester
        '
        Me.lblSemester.AutoSize = True
        Me.lblSemester.Location = New System.Drawing.Point(140, 57)
        Me.lblSemester.Name = "lblSemester"
        Me.lblSemester.Size = New System.Drawing.Size(72, 17)
        Me.lblSemester.TabIndex = 5
        Me.lblSemester.Text = "Semester:"
        '
        'lblStudentCnt
        '
        Me.lblStudentCnt.AutoSize = True
        Me.lblStudentCnt.Location = New System.Drawing.Point(110, 85)
        Me.lblStudentCnt.Name = "lblStudentCnt"
        Me.lblStudentCnt.Size = New System.Drawing.Size(102, 17)
        Me.lblStudentCnt.TabIndex = 6
        Me.lblStudentCnt.Text = "Student Count:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(0, 113)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(212, 17)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Textbook ISBN 13-Digit Number:"
        '
        'btnAddCourse
        '
        Me.btnAddCourse.Location = New System.Drawing.Point(25, 167)
        Me.btnAddCourse.Name = "btnAddCourse"
        Me.btnAddCourse.Size = New System.Drawing.Size(159, 39)
        Me.btnAddCourse.TabIndex = 8
        Me.btnAddCourse.Text = "Add Course"
        Me.btnAddCourse.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(218, 167)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(159, 39)
        Me.btnClose.TabIndex = 9
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'frmAddCourse
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(406, 244)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAddCourse)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblStudentCnt)
        Me.Controls.Add(Me.lblSemester)
        Me.Controls.Add(Me.lblInstructor)
        Me.Controls.Add(Me.txtTextbook)
        Me.Controls.Add(Me.txtStudentCnt)
        Me.Controls.Add(Me.txtSemester)
        Me.Controls.Add(Me.txtInstructor)
        Me.Name = "frmAddCourse"
        Me.Text = "Add Course"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtInstructor As TextBox
    Friend WithEvents txtSemester As TextBox
    Friend WithEvents txtStudentCnt As TextBox
    Friend WithEvents txtTextbook As TextBox
    Friend WithEvents lblInstructor As Label
    Friend WithEvents lblSemester As Label
    Friend WithEvents lblStudentCnt As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents btnAddCourse As Button
    Friend WithEvents btnClose As Button
End Class
